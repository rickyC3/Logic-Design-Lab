# Logic_Design_Lab_Final_project
### NTHU verilog lab class -- final project

<p> 
robot, dragon size: 40*30 (width*height) <br>
missile image size: (56*12)<br>
robot's coe pls chooose robot.coe<br>
and dragon's coe pls choose dragon_pixel_1.coe<br>
and missile's coe pls choose missile_3.coe
and background picture coe pls choose Universe0.coe and Universe1.coe(size 160*120)<br>
</p>

---

<p>

操作說明
使用wasd控制角色移動，空白鑑發射飛彈。<br>
發射飛彈有一段cd時間(裝填時間)<br>
碰到龍角色即死亡，龍在隨機狀態下有機率是無敵狀態。<br>
</p>

---

<p>
要提取檔案時，要注意抓的coe檔案對不對(還有大小)。<br>
此外，tmp.v、empty.txt、tmp.txt檔都是empty file，可以忽略它(只是在建立github資料夾時建立的)。
</p>